#define _GNU_SOURCE
#include "alert.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

static config_t *cfg;
static FILE *logf;
static int notify_on;
static int state[3];            /* 0 = NORMAL, 1 = ALERTING */
static time_t last_alert[3];
static long counts[4];
#define RING 20
static alert_event_t ring[RING];
static int ring_n, ring_head;
static const char *RES_NAME[3] = {"CPU", "MEMORY", "DISK"};
static const char *LEVEL[4] = {"", "ALERT", "REMINDER", "RECOVERED"};

static void stamp(char *buf, size_t n, time_t t)
{
    struct tm tmv;
    localtime_r(&t, &tmv);
    strftime(buf, n, "%Y-%m-%d %H:%M:%S", &tmv);
}

void log_line(const char *level, const char *fmt, ...)
{
    char ts[20];
    va_list ap;
    if (logf == NULL) return;
    stamp(ts, sizeof ts, time(NULL));
    fprintf(logf, "%s [%s] ", ts, level);
    va_start(ap, fmt); vfprintf(logf, fmt, ap); va_end(ap);
    fputc('\n', logf);
    fflush(logf);                     /* the record survives Ctrl+C or a crash */
}

int alert_init(config_t *c)
{
    cfg = c;
    memset(state, 0, sizeof state); memset(counts, 0, sizeof counts);
    ring_n = ring_head = 0;
    logf = fopen(c->logfile, "a");
    if (logf == NULL) fprintf(stderr, "warning: cannot open log file '%s'; continuing with console alerts only\n", c->logfile);
    notify_on = c->notify;
    if (notify_on && system("command -v notify-send >/dev/null 2>&1") != 0) {
        printf("info: notify-send not available; desktop notifications disabled (console and log still work)\n");
        notify_on = 0;
    }
    return 0;
}

void alert_close(void)
{
    if (logf) { fclose(logf); logf = NULL; }
}

static void emit(int ev, int res, double value, time_t now)
{
    char ts[20], text[160], cmd[320];
    stamp(ts, sizeof ts, now);
    if (ev == EV_RECOVERED)
        snprintf(text, sizeof text, "%s usage %.1f%% is back below threshold %.1f%%", RES_NAME[res], value, cfg->th[res]);
    else if (ev == EV_REMINDER)
        snprintf(text, sizeof text, "%s usage %.1f%% still above threshold %.1f%%", RES_NAME[res], value, cfg->th[res]);
    else
        snprintf(text, sizeof text, "%s usage %.1f%% exceeds threshold %.1f%%", RES_NAME[res], value, cfg->th[res]);
    printf("%s [%-9s] %s\n", ts, LEVEL[ev], text);
    fflush(stdout);
    log_line(LEVEL[ev], "%s", text);
    counts[ev]++;
    alert_event_t *e = &ring[ring_head];
    snprintf(e->time, sizeof e->time, "%s", ts);
    snprintf(e->level, sizeof e->level, "%s", LEVEL[ev]);
    snprintf(e->text, sizeof e->text, "%s", text);
    ring_head = (ring_head + 1) % RING;
    if (ring_n < RING) ring_n++;
    if (notify_on && ev != EV_REMINDER) {             /* text contains only our own generated characters */
        snprintf(cmd, sizeof cmd, "notify-send 'Resource %s' '%s' >/dev/null 2>&1", LEVEL[ev], text);
        if (system(cmd) != 0) {
            printf("info: notify-send failed; desktop notifications disabled\n");
            notify_on = 0;
        }
    }
}

int alert_check(int res, double value, time_t now)
{
    int ev = EV_NONE;
    if (value > cfg->th[res]) {
        if (state[res] == 0) { ev = EV_ALERT; state[res] = 1; last_alert[res] = now; }
        else if (now - last_alert[res] >= cfg->cooldown) { ev = EV_REMINDER; last_alert[res] = now; }
    } else if (state[res] == 1) {
        ev = EV_RECOVERED; state[res] = 0;
    }
    if (ev != EV_NONE) emit(ev, res, value, now);
    return ev;
}

int alert_is_alerting(int res) { return state[res]; }
long alert_count(int ev) { return counts[ev]; }

int alert_recent(alert_event_t *out, int max)
{
    int n = ring_n < max ? ring_n : max;
    for (int i = 0; i < n; i++) out[i] = ring[(ring_head - 1 - i + RING * 2) % RING];
    return n;
}
