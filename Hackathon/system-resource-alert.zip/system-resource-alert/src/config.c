#define _GNU_SOURCE
#include "config.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <getopt.h>

void config_defaults(config_t *c)
{
    memset(c, 0, sizeof *c);
    c->th[0] = 80; c->th[1] = 80; c->th[2] = 90;
    strcpy(c->path, "/");
    c->interval = 2; c->cooldown = 30; c->top = 5; c->port = 8080; c->notify = 1;
    strcpy(c->logfile, "logs/alerts.log");
    strcpy(c->webdir, "web");
}

int parse_double_strict(const char *s, double *out)
{
    char *end;
    if (s == NULL || *s == '\0') return -1;
    *out = strtod(s, &end);
    return (*end == '\0') ? 0 : -1;
}

static int parse_int_strict(const char *s, int *out)
{
    char *end;
    long v;
    if (s == NULL || *s == '\0') return -1;
    v = strtol(s, &end, 10);
    if (*end != '\0' || v < -2000000000L || v > 2000000000L) return -1;
    *out = (int)v;
    return 0;
}

/* Apply one key/value pair (used by the config file and by the options). */
static int apply(config_t *c, const char *key, const char *val)
{
    double d; int i;
    if (!strcmp(key, "cpu_threshold"))  { if (parse_double_strict(val, &d)) goto bad; c->th[0] = d; }
    else if (!strcmp(key, "mem_threshold"))  { if (parse_double_strict(val, &d)) goto bad; c->th[1] = d; }
    else if (!strcmp(key, "disk_threshold")) { if (parse_double_strict(val, &d)) goto bad; c->th[2] = d; }
    else if (!strcmp(key, "disk_path"))  snprintf(c->path, sizeof c->path, "%s", val);
    else if (!strcmp(key, "interval"))   { if (parse_int_strict(val, &i)) goto bad; c->interval = i; }
    else if (!strcmp(key, "cooldown"))   { if (parse_int_strict(val, &i)) goto bad; c->cooldown = i; }
    else if (!strcmp(key, "top_processes")) { if (parse_int_strict(val, &i)) goto bad; c->top = i; }
    else if (!strcmp(key, "port"))       { if (parse_int_strict(val, &i)) goto bad; c->port = i; }
    else if (!strcmp(key, "log_file"))   snprintf(c->logfile, sizeof c->logfile, "%s", val);
    else if (!strcmp(key, "notifications")) c->notify = !strcmp(val, "on");
    else { fprintf(stderr, "error: unknown setting '%s'\n", key); return -1; }
    return 0;
bad:
    fprintf(stderr, "error: invalid value '%s' for '%s'\n", val, key);
    return -1;
}

int config_load_file(config_t *c, const char *file)
{
    char line[512];
    FILE *fp = fopen(file, "r");
    if (fp == NULL) { fprintf(stderr, "error: cannot open config file '%s'\n", file); return -1; }
    while (fgets(line, sizeof line, fp)) {
        char *eq, *k = line, *v;
        while (isspace((unsigned char)*k)) k++;
        if (*k == '#' || *k == '\0') continue;
        eq = strchr(k, '=');
        if (eq == NULL) continue;
        *eq = '\0'; v = eq + 1;
        for (char *e = k + strlen(k); e > k && isspace((unsigned char)e[-1]); ) *--e = '\0';
        while (isspace((unsigned char)*v)) v++;
        for (char *e = v + strlen(v); e > v && isspace((unsigned char)e[-1]); ) *--e = '\0';
        if (apply(c, k, v) != 0) { fclose(fp); return -1; }
    }
    fclose(fp);
    return 0;
}

void config_usage(const char *p)
{
    printf("Usage: %s [options]\n"
           "  -c, --cpu N         CPU threshold %% (default 80)\n"
           "  -m, --mem N         memory threshold %% (default 80)\n"
           "  -d, --disk N        disk threshold %% (default 90)\n"
           "  -p, --path DIR      directory to monitor for disk usage (default /)\n"
           "  -i, --interval S    refresh interval seconds, 1-3600 (default 2)\n"
           "  -k, --cooldown S    seconds between repeated alerts (default 30)\n"
           "  -n, --top N         processes to show, 1-20 (default 5)\n"
           "  -l, --log FILE      log file (default logs/alerts.log)\n"
           "  -f, --config FILE   read settings from FILE\n"
           "  -P, --port N        web dashboard port, 0 = console only (default 8080)\n"
           "  -w, --web DIR       folder containing index.html (default web)\n"
           "      --count N       stop after N samples\n"
           "      --no-notify     disable desktop notifications\n"
           "      --test-mode F   use SIMULATED 'cpu mem disk' lines from file F\n"
           "  -h, --help\n", p);
}

int config_parse_args(config_t *c, int argc, char **argv)
{
    static const struct option lo[] = {
        {"cpu",1,0,'c'},{"mem",1,0,'m'},{"disk",1,0,'d'},{"path",1,0,'p'},{"interval",1,0,'i'},
        {"cooldown",1,0,'k'},{"top",1,0,'n'},{"log",1,0,'l'},{"config",1,0,'f'},{"port",1,0,'P'},
        {"web",1,0,'w'},{"count",1,0,256},{"no-notify",0,0,257},{"test-mode",1,0,258},{"help",0,0,'h'},{0,0,0,0}};
    int o, i;
    /* pass 1: load the config file first so that options can override it */
    for (i = 1; i < argc - 1; i++)
        if (!strcmp(argv[i], "-f") || !strcmp(argv[i], "--config"))
            if (config_load_file(c, argv[i + 1]) != 0) return -1;
    optind = 1;
    while ((o = getopt_long(argc, argv, "c:m:d:p:i:k:n:l:f:P:w:h", lo, NULL)) != -1) {
        int rc = 0, v;
        switch (o) {
        case 'c': rc = apply(c, "cpu_threshold", optarg); break;
        case 'm': rc = apply(c, "mem_threshold", optarg); break;
        case 'd': rc = apply(c, "disk_threshold", optarg); break;
        case 'p': rc = apply(c, "disk_path", optarg); break;
        case 'i': rc = apply(c, "interval", optarg); break;
        case 'k': rc = apply(c, "cooldown", optarg); break;
        case 'n': rc = apply(c, "top_processes", optarg); break;
        case 'l': rc = apply(c, "log_file", optarg); break;
        case 'P': rc = apply(c, "port", optarg); break;
        case 'w': snprintf(c->webdir, sizeof c->webdir, "%s", optarg); break;
        case 'f': break;
        case 256: { char *end; v = (int)strtol(optarg, &end, 10);
                    if (*optarg == '\0' || *end != '\0') { fprintf(stderr, "error: invalid --count '%s'\n", optarg); return -1; }
                    c->count = v; break; }
        case 257: c->notify = 0; break;
        case 258: snprintf(c->testfile, sizeof c->testfile, "%s", optarg); break;
        case 'h': return 1;
        default: return -1;
        }
        if (rc != 0) return -1;
    }
    return 0;
}

int config_validate(const config_t *c)
{
    static const char *n[3] = {"CPU", "memory", "disk"};
    for (int i = 0; i < 3; i++)
        if (!(c->th[i] >= 0.0 && c->th[i] <= 100.0)) {
            fprintf(stderr, "error: %s threshold must be between 0 and 100 (got %.1f)\n", n[i], c->th[i]);
            return -1;
        }
    if (c->interval < 1 || c->interval > 3600) { fprintf(stderr, "error: interval must be 1-3600 seconds\n"); return -1; }
    if (c->cooldown < 0 || c->cooldown > 86400) { fprintf(stderr, "error: cooldown must be 0-86400 seconds\n"); return -1; }
    if (c->top < 1 || c->top > 20) { fprintf(stderr, "error: top must be 1-20\n"); return -1; }
    if (c->port < 0 || c->port > 65535) { fprintf(stderr, "error: port must be 0-65535\n"); return -1; }
    if (c->count < 0) { fprintf(stderr, "error: count must be >= 0\n"); return -1; }
    return 0;
}
