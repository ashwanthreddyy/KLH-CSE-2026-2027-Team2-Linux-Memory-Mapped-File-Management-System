#define _GNU_SOURCE
#include "monitors.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <dirent.h>
#include <time.h>
#include <unistd.h>
#include <sys/statvfs.h>

/* ---------- CPU: interval-based, from two samples of /proc/stat ---------- */
int cpu_read_sample(cpu_sample_t *s)
{
    char line[256];
    int n = 0;
    FILE *fp = fopen("/proc/stat", "r");
    if (fp == NULL) return -1;
    memset(s, 0, sizeof *s);                       /* older kernels have fewer fields */
    if (fgets(line, sizeof line, fp) != NULL)
        n = sscanf(line, "cpu %llu %llu %llu %llu %llu %llu %llu %llu",
                   &s->user, &s->nice, &s->system, &s->idle,
                   &s->iowait, &s->irq, &s->softirq, &s->steal);
    fclose(fp);
    return (n >= 4) ? 0 : -1;
}

double cpu_usage_percent(const cpu_sample_t *p, const cpu_sample_t *c)
{
    unsigned long long idle_p = p->idle + p->iowait, idle_c = c->idle + c->iowait;
    unsigned long long tot_p = idle_p + p->user + p->nice + p->system + p->irq + p->softirq + p->steal;
    unsigned long long tot_c = idle_c + c->user + c->nice + c->system + c->irq + c->softirq + c->steal;
    if (tot_c <= tot_p || idle_c < idle_p) return 0.0;   /* no progress or counter reset */
    double dt = (double)(tot_c - tot_p), di = (double)(idle_c - idle_p);
    double pct = 100.0 * (dt - di) / dt;
    return pct < 0.0 ? 0.0 : (pct > 100.0 ? 100.0 : pct);
}

/* ---------- Memory: instantaneous, from /proc/meminfo ---------- */
int mem_read(mem_info_t *m)
{
    char line[128];
    unsigned long long v, total = 0, avail = 0, freekb = 0, buf = 0, cache = 0;
    int have_avail = 0;
    FILE *fp = fopen("/proc/meminfo", "r");
    if (fp == NULL) return -1;
    while (fgets(line, sizeof line, fp) != NULL) {
        if (sscanf(line, "MemTotal: %llu kB", &v) == 1) total = v;
        else if (sscanf(line, "MemAvailable: %llu kB", &v) == 1) { avail = v; have_avail = 1; }
        else if (sscanf(line, "MemFree: %llu kB", &v) == 1) freekb = v;
        else if (sscanf(line, "Buffers: %llu kB", &v) == 1) buf = v;
        else if (sscanf(line, "Cached: %llu kB", &v) == 1) cache = v;
    }
    fclose(fp);
    if (total == 0) return -1;
    if (!have_avail) avail = freekb + buf + cache;   /* fallback for very old kernels */
    if (avail > total) avail = total;
    m->total_kb = total; m->avail_kb = avail; m->used_kb = total - avail;
    m->percent = 100.0 * (double)m->used_kb / (double)total;
    return 0;
}

/* ---------- Disk: instantaneous, from statvfs() (same convention as df) ---------- */
int disk_read(const char *path, disk_info_t *d)
{
    struct statvfs sv;
    if (statvfs(path, &sv) != 0) return -1;
    double fr = (double)sv.f_frsize;
    d->total = (double)sv.f_blocks * fr;
    d->used  = (double)(sv.f_blocks - sv.f_bfree) * fr;
    d->avail = (double)sv.f_bavail * fr;
    double denom = d->used + d->avail;
    d->percent = (denom > 0.0) ? 100.0 * d->used / denom : 0.0;
    return 0;
}

/* ---------- Processes: /proc/[pid]/stat (CPU ticks) and statm (resident pages) ---------- */
int proc_parse_stat(const char *buf, char *name, unsigned long name_len,
                    unsigned long long *utime, unsigned long long *stime)
{
    /* The name is in parentheses and may itself contain spaces or ')' -> use the LAST ')' */
    const char *open = strchr(buf, '('), *close = strrchr(buf, ')');
    if (open == NULL || close == NULL || close < open) return -1;
    unsigned long len = (unsigned long)(close - open - 1);
    if (len >= name_len) len = name_len - 1;
    memcpy(name, open + 1, len);
    name[len] = '\0';
    char state; int si; unsigned long su;
    int got = sscanf(close + 1, " %c %d %d %d %d %d %lu %lu %lu %lu %lu %llu %llu",
                     &state, &si, &si, &si, &si, &si, &su, &su, &su, &su, &su, utime, stime);
    return (got == 13) ? 0 : -1;
}

typedef struct { int pid; unsigned long long ticks; } prev_t;
#define PREV_SLOTS 8192
static prev_t prev_tab[PREV_SLOTS];     /* direct-mapped by pid; a collision only costs one 0% reading */
static double last_time = 0.0;
static int have_prev = 0;

static double mono_seconds(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1e9;
}
static int better(const proc_info_t *a, const proc_info_t *b)
{
    if (a->cpu != b->cpu) return a->cpu > b->cpu;
    return a->rss_mb > b->rss_mb;
}

int proc_top(proc_info_t *out, int n, unsigned long long mem_total_kb)
{
    DIR *d = opendir("/proc");
    struct dirent *e;
    int cnt = 0;
    double now = mono_seconds(), el = now - last_time;
    long tck = sysconf(_SC_CLK_TCK), pgsz = sysconf(_SC_PAGESIZE);
    if (d == NULL) return 0;
    while ((e = readdir(d)) != NULL) {
        if (!isdigit((unsigned char)e->d_name[0])) continue;
        int pid = atoi(e->d_name);
        if (pid <= 0) continue;
        char path[64], buf[1024];
        snprintf(path, sizeof path, "/proc/%d/stat", pid);
        FILE *f = fopen(path, "r");
        if (f == NULL) continue;                       /* vanished or not permitted */
        size_t len = fread(buf, 1, sizeof buf - 1, f);
        fclose(f);
        if (len == 0) continue;
        buf[len] = '\0';
        proc_info_t p; unsigned long long ut, st;
        if (proc_parse_stat(buf, p.name, sizeof p.name, &ut, &st) != 0) continue;   /* malformed */
        p.pid = pid; p.cpu = 0.0;
        unsigned long long ticks = ut + st;
        prev_t *s = &prev_tab[pid % PREV_SLOTS];
        if (have_prev && s->pid == pid && el > 0.0 && ticks >= s->ticks)
            p.cpu = 100.0 * (double)(ticks - s->ticks) / ((double)tck * el);
        s->pid = pid; s->ticks = ticks;
        p.rss_mb = 0.0;
        snprintf(path, sizeof path, "/proc/%d/statm", pid);
        if ((f = fopen(path, "r")) != NULL) {
            unsigned long sz, rs;
            if (fscanf(f, "%lu %lu", &sz, &rs) == 2) p.rss_mb = (double)rs * (double)pgsz / 1048576.0;
            fclose(f);
        }
        p.mem_pct = mem_total_kb ? 100.0 * (p.rss_mb * 1024.0) / (double)mem_total_kb : 0.0;
        int idx;
        if (cnt < n) idx = cnt++;
        else if (better(&p, &out[n - 1])) idx = n - 1;
        else continue;
        out[idx] = p;
        for (; idx > 0 && better(&out[idx], &out[idx - 1]); idx--) {
            proc_info_t t = out[idx]; out[idx] = out[idx - 1]; out[idx - 1] = t;
        }
    }
    closedir(d);
    last_time = now; have_prev = 1;
    return cnt;
}
