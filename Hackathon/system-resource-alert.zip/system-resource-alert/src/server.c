#define _GNU_SOURCE
#include "server.h"
#include "alert.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <poll.h>
#include <signal.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/time.h>

int server_open(int port)
{
    int fd = socket(AF_INET, SOCK_STREAM, 0), one = 1;
    struct sockaddr_in a;
    if (fd < 0) return -1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one);
    memset(&a, 0, sizeof a);
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);      /* local machine only */
    a.sin_port = htons((unsigned short)port);
    if (bind(fd, (struct sockaddr *)&a, sizeof a) != 0 || listen(fd, 8) != 0) { close(fd); return -1; }
    return fd;
}

static void send_all(int fd, const char *p, size_t n)
{
    while (n > 0) {
        ssize_t w = send(fd, p, n, MSG_NOSIGNAL);
        if (w <= 0) return;
        p += w; n -= (size_t)w;
    }
}

static void reply(int fd, int code, const char *type, const char *body, size_t len)
{
    char h[256];
    int n = snprintf(h, sizeof h, "HTTP/1.1 %d %s\r\nContent-Type: %s\r\nContent-Length: %zu\r\n"
                     "Cache-Control: no-store\r\nConnection: close\r\n\r\n",
                     code, code == 200 ? "OK" : (code == 400 ? "Bad Request" : "Not Found"), type, len);
    send_all(fd, h, (size_t)n);
    send_all(fd, body, len);
}

static void json_escape(char *dst, size_t n, const char *src)
{
    size_t j = 0;
    for (size_t i = 0; src[i] && j + 7 < n; i++) {
        unsigned char c = (unsigned char)src[i];
        if (c == '"' || c == '\\') { dst[j++] = '\\'; dst[j++] = (char)c; }
        else if (c < 32) j += (size_t)snprintf(dst + j, n - j, "\\u%04x", c);
        else dst[j++] = (char)c;
    }
    dst[j] = '\0';
}

static void send_status(int fd, const snapshot_t *s, const config_t *cfg)
{
    static char b[20000];
    static const char *names[3] = {"cpu", "mem", "disk"};
    double vals[3] = {s->cpu, s->mem.percent, s->disk.percent};
    int n = snprintf(b, sizeof b, "{\"time\":\"%s\",\"simulated\":%s,\"interval\":%d,\"cooldown\":%d,\"path\":\"", s->time,
                     s->simulated ? "true" : "false", cfg->interval, cfg->cooldown);
    char esc[512];
    json_escape(esc, sizeof esc, cfg->path);
    n += snprintf(b + n, sizeof b - (size_t)n, "%s\",", esc);
    for (int i = 0; i < 3; i++)
        n += snprintf(b + n, sizeof b - (size_t)n, "\"%s\":{\"value\":%.1f,\"threshold\":%.1f,\"state\":\"%s\"},",
                      names[i], vals[i], cfg->th[i], alert_is_alerting(i) ? "ALERT" : "OK");
    n += snprintf(b + n, sizeof b - (size_t)n,
                  "\"memory\":{\"used_mb\":%.0f,\"total_mb\":%.0f,\"avail_mb\":%.0f},"
                  "\"diskinfo\":{\"used_gb\":%.2f,\"total_gb\":%.2f,\"avail_gb\":%.2f},\"procs\":[",
                  s->mem.used_kb / 1024.0, s->mem.total_kb / 1024.0, s->mem.avail_kb / 1024.0,
                  s->disk.used / 1073741824.0, s->disk.total / 1073741824.0, s->disk.avail / 1073741824.0);
    for (int i = 0; i < s->nprocs; i++) {
        json_escape(esc, sizeof esc, s->procs[i].name);
        n += snprintf(b + n, sizeof b - (size_t)n, "%s{\"pid\":%d,\"name\":\"%s\",\"cpu\":%.1f,\"rss_mb\":%.1f}",
                      i ? "," : "", s->procs[i].pid, esc, s->procs[i].cpu, s->procs[i].rss_mb);
    }
    n += snprintf(b + n, sizeof b - (size_t)n, "],\"alerts\":[");
    alert_event_t ev[20];
    int k = alert_recent(ev, 20);
    for (int i = 0; i < k; i++) {
        char t[400];
        json_escape(t, sizeof t, ev[i].text);
        n += snprintf(b + n, sizeof b - (size_t)n, "%s{\"time\":\"%s\",\"level\":\"%s\",\"text\":\"%s\"}",
                      i ? "," : "", ev[i].time, ev[i].level, t);
    }
    n += snprintf(b + n, sizeof b - (size_t)n, "]}");
    reply(fd, 200, "application/json", b, (size_t)n);
}

static int query_value(const char *q, const char *key, double *out)
{
    char pat[16], num[32];
    const char *p;
    snprintf(pat, sizeof pat, "%s=", key);
    p = strstr(q, pat);
    if (p == NULL || (p != q && p[-1] != '&' && p[-1] != '?')) return 0;      /* not present */
    p += strlen(pat);
    size_t i = 0;
    while (p[i] && p[i] != '&' && p[i] != ' ' && i < sizeof num - 1) { num[i] = p[i]; i++; }
    num[i] = '\0';
    return parse_double_strict(num, out) == 0 ? 1 : -1;                       /* 1 ok, -1 invalid */
}

static void handle_config(int fd, const char *query, config_t *cfg)
{
    static const char *keys[3] = {"cpu", "mem", "disk"};
    double v[3]; int have[3], bad = 0;
    char msg[96];
    for (int i = 0; i < 3; i++) {
        have[i] = query_value(query, keys[i], &v[i]);
        if (have[i] == -1 || (have[i] == 1 && !(v[i] >= 0.0 && v[i] <= 100.0))) bad = 1;
    }
    if (bad) {
        snprintf(msg, sizeof msg, "{\"ok\":false,\"error\":\"thresholds must be numbers between 0 and 100\"}");
        reply(fd, 400, "application/json", msg, strlen(msg));
        return;
    }
    for (int i = 0; i < 3; i++) if (have[i] == 1) cfg->th[i] = v[i];
    log_line("INFO", "thresholds set from dashboard: CPU %.1f MEMORY %.1f DISK %.1f", cfg->th[0], cfg->th[1], cfg->th[2]);
    snprintf(msg, sizeof msg, "{\"ok\":true}");
    reply(fd, 200, "application/json", msg, strlen(msg));
}

static void serve_index(int fd, const config_t *cfg)
{
    char path[600];
    snprintf(path, sizeof path, "%s/index.html", cfg->webdir);
    FILE *f = fopen(path, "rb");
    if (f == NULL) { const char *m = "index.html not found. Run from the project folder or use --web DIR."; reply(fd, 404, "text/plain", m, strlen(m)); return; }
    fseek(f, 0, SEEK_END); long sz = ftell(f); fseek(f, 0, SEEK_SET);
    char *buf = malloc((size_t)sz + 1);
    if (buf == NULL) { fclose(f); return; }
    size_t got = fread(buf, 1, (size_t)sz, f);
    fclose(f);
    reply(fd, 200, "text/html; charset=utf-8", buf, got);
    free(buf);
}

void server_poll(int fd, int timeout_ms, const snapshot_t *snap, config_t *cfg)
{
    struct pollfd p = {fd, POLLIN, 0};
    if (poll(&p, 1, timeout_ms) <= 0) return;                 /* timeout or interrupted by Ctrl+C */
    int c = accept(fd, NULL, NULL);
    if (c < 0) return;
    struct timeval tv = {1, 0};
    setsockopt(c, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
    char req[2048];
    ssize_t n = recv(c, req, sizeof req - 1, 0);
    if (n > 0) {
        req[n] = '\0';
        char method[8], target[512];
        if (sscanf(req, "%7s %511s", method, target) != 2 || strcmp(method, "GET") != 0) {
            const char *m = "bad request"; reply(c, 400, "text/plain", m, strlen(m));
        } else if (!strcmp(target, "/") || !strcmp(target, "/index.html")) serve_index(c, cfg);
        else if (!strcmp(target, "/api/status")) send_status(c, snap, cfg);
        else if (!strncmp(target, "/api/config", 11)) handle_config(c, strchr(target, '?') ? strchr(target, '?') + 1 : "", cfg);
        else { const char *m = "not found"; reply(c, 404, "text/plain", m, strlen(m)); }
    }
    close(c);
}
