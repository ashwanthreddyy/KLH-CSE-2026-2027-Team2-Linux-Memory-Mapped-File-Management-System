#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <time.h>
#include <unistd.h>
#include "config.h"
#include "monitors.h"
#include "alert.h"
#include "server.h"

static volatile sig_atomic_t g_running = 1;
static void on_signal(int sig) { (void)sig; g_running = 0; }   /* only sets a flag */

static double mono(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1e9;
}

int main(int argc, char **argv)
{
    config_t cfg;
    snapshot_t snap;
    cpu_sample_t prev, cur;
    FILE *test = NULL;
    int sfd = -1, samples = 0, disk_failed = 0;

    config_defaults(&cfg);
    int rc = config_parse_args(&cfg, argc, argv);
    if (rc == 1) { config_usage(argv[0]); return 0; }
    if (rc < 0 || config_validate(&cfg) != 0) { fprintf(stderr, "Try '%s --help'.\n", argv[0]); return 1; }
    disk_info_t probe;
    if (disk_read(cfg.path, &probe) != 0) { fprintf(stderr, "error: cannot read file system of path '%s'\n", cfg.path); return 1; }
    if (cfg.testfile[0] && (test = fopen(cfg.testfile, "r")) == NULL) { fprintf(stderr, "error: cannot open test file '%s'\n", cfg.testfile); return 1; }

    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = on_signal; sigemptyset(&sa.sa_mask);
    sigaction(SIGINT, &sa, NULL); sigaction(SIGTERM, &sa, NULL);

    alert_init(&cfg);
    log_line("INFO", "monitoring started: CPU>%.1f MEMORY>%.1f DISK>%.1f path=%s interval=%ds cooldown=%ds%s",
             cfg.th[0], cfg.th[1], cfg.th[2], cfg.path, cfg.interval, cfg.cooldown, test ? " (SIMULATED test mode)" : "");
    if (cpu_read_sample(&prev) != 0) { fprintf(stderr, "error: cannot read /proc/stat\n"); return 1; }
    mem_info_t m0; mem_read(&m0);
    proc_info_t dummy[20]; proc_top(dummy, 1, m0.total_kb);          /* baseline for process CPU */
    if (cfg.port > 0) {
        sfd = server_open(cfg.port);
        if (sfd < 0) fprintf(stderr, "warning: cannot open port %d (in use?); running without web dashboard\n", cfg.port);
        else printf("Web dashboard: http://localhost:%d   (Ctrl+C to stop)\n", cfg.port);
    }
    memset(&snap, 0, sizeof snap);
    snap.simulated = test != NULL;

    double next = mono() + cfg.interval;
    while (g_running) {
        /* wait for the next sample while answering web requests */
        for (double rem = next - mono(); g_running && rem > 0; rem = next - mono()) {
            if (sfd >= 0) server_poll(sfd, (int)(rem * 1000) + 1, &snap, &cfg);
            else { struct timespec t = {0, 100000000L}; nanosleep(&t, NULL); }
        }
        if (!g_running) break;
        next += cfg.interval;

        if (cpu_read_sample(&cur) == 0) { snap.cpu = cpu_usage_percent(&prev, &cur); prev = cur; }
        else log_line("ERROR", "cannot read /proc/stat; keeping previous CPU value");
        if (mem_read(&snap.mem) != 0) log_line("ERROR", "cannot read /proc/meminfo; keeping previous memory value");
        if (disk_read(cfg.path, &snap.disk) != 0) {
            if (!disk_failed) log_line("ERROR", "statvfs failed for %s; keeping previous disk value", cfg.path);
            disk_failed = 1;
        } else disk_failed = 0;
        snap.nprocs = proc_top(snap.procs, cfg.top, snap.mem.total_kb);

        if (test) {                                    /* simulated values override the live ones */
            char line[128]; double c, m, d; int got = 0;
            while (fgets(line, sizeof line, test)) {
                if (line[0] == '#' || line[0] == '\n') continue;
                if (sscanf(line, "%lf %lf %lf", &c, &m, &d) == 3) { got = 1; break; }
            }
            if (!got) { printf("test data finished\n"); break; }
            snap.cpu = c; snap.mem.percent = m; snap.disk.percent = d;
        }
        time_t now = time(NULL);
        struct tm tmv; localtime_r(&now, &tmv);
        strftime(snap.time, sizeof snap.time, "%Y-%m-%d %H:%M:%S", &tmv);

        alert_check(R_CPU, snap.cpu, now);
        alert_check(R_MEM, snap.mem.percent, now);
        alert_check(R_DISK, snap.disk.percent, now);
        printf("%s%s CPU %5.1f%% | MEM %5.1f%% | DISK(%s) %5.1f%%\n", snap.time, test ? " [SIMULATED]" : "",
               snap.cpu, snap.mem.percent, cfg.path, snap.disk.percent);
        log_line("INFO", "%sCPU=%.1f%% MEM=%.1f%% DISK=%.1f%%", test ? "[SIMULATED] " : "", snap.cpu, snap.mem.percent, snap.disk.percent);
        fflush(stdout);
        if (cfg.count > 0 && ++samples >= cfg.count) break;
    }
    log_line("INFO", "monitoring stopped (%ld alerts, %ld reminders, %ld recoveries)",
             alert_count(EV_ALERT), alert_count(EV_REMINDER), alert_count(EV_RECOVERED));
    printf("\nStopped cleanly.\n");
    alert_close();
    if (sfd >= 0) close(sfd);
    if (test) fclose(test);
    return 0;
}
