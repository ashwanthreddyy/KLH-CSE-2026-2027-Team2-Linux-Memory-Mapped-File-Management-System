#ifndef SERVER_H
#define SERVER_H
#include "config.h"
#include "monitors.h"
typedef struct {
    char time[20];
    int simulated, nprocs;
    double cpu;
    mem_info_t mem;
    disk_info_t disk;
    proc_info_t procs[20];
} snapshot_t;
int  server_open(int port);          /* listens on 127.0.0.1 only; returns fd or -1 */
/* Waits up to timeout_ms for one request and answers it. */
void server_poll(int fd, int timeout_ms, const snapshot_t *snap, config_t *cfg);
#endif
