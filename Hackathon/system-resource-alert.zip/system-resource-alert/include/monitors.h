#ifndef MONITORS_H
#define MONITORS_H
/* CPU, memory, disk and process monitors (the only code that touches /proc and statvfs). */
typedef struct { unsigned long long user, nice, system, idle, iowait, irq, softirq, steal; } cpu_sample_t;
typedef struct { unsigned long long total_kb, used_kb, avail_kb; double percent; } mem_info_t;
typedef struct { double total, used, avail, percent; } disk_info_t;      /* bytes */
typedef struct { int pid; char name[64]; double cpu, rss_mb, mem_pct; } proc_info_t;

int    cpu_read_sample(cpu_sample_t *s);
double cpu_usage_percent(const cpu_sample_t *prev, const cpu_sample_t *cur);
int    mem_read(mem_info_t *m);
int    disk_read(const char *path, disk_info_t *d);
int    proc_parse_stat(const char *buf, char *name, unsigned long name_len,
                       unsigned long long *utime, unsigned long long *stime);
/* Fills out[0..n-1] with the top processes; returns how many. Keeps state between calls. */
int    proc_top(proc_info_t *out, int n, unsigned long long mem_total_kb);
#endif
