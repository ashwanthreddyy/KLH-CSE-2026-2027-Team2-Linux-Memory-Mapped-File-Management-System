#ifndef ALERT_H
#define ALERT_H
#include <time.h>
#include "config.h"
/* Alert engine + logger + optional desktop notifier. */
enum { R_CPU = 0, R_MEM = 1, R_DISK = 2 };
enum { EV_NONE = 0, EV_ALERT = 1, EV_REMINDER = 2, EV_RECOVERED = 3 };
typedef struct { char time[20], level[12], text[160]; } alert_event_t;

int  alert_init(config_t *cfg);                 /* opens the log; returns 0 even if the log cannot be opened */
void alert_close(void);
int  alert_check(int res, double value, time_t now);   /* returns an EV_* code */
int  alert_is_alerting(int res);
long alert_count(int ev);
int  alert_recent(alert_event_t *out, int max); /* newest first */
void log_line(const char *level, const char *fmt, ...);   /* timestamped line to the log file */
#endif
