#ifndef CONFIG_H
#define CONFIG_H
/* Runtime settings: defaults, config file, command-line options, validation. */
typedef struct {
    double th[3];            /* thresholds: [0]=CPU [1]=MEMORY [2]=DISK, percent */
    char   path[256];        /* directory whose file system is monitored */
    int    interval, cooldown, top, port, notify, count;
    char   logfile[256], webdir[256], testfile[256];
} config_t;

void config_defaults(config_t *c);
int  config_load_file(config_t *c, const char *file);      /* 0 ok, -1 error */
int  config_parse_args(config_t *c, int argc, char **argv); /* 0 ok, 1 help, -1 error */
int  config_validate(const config_t *c);                    /* 0 ok, -1 error (message printed) */
int  parse_double_strict(const char *s, double *out);       /* 0 ok */
void config_usage(const char *prog);
#endif
