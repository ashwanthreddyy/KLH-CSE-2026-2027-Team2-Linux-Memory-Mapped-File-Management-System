/* Deterministic unit tests: fixed inputs, known outputs. No real system load is needed. */
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "config.h"
#include "monitors.h"
#include "alert.h"

static int failed = 0;
#define CHECK(cond, msg) do { if (cond) printf("PASS  %s\n", msg); else { printf("FAIL  %s\n", msg); failed++; } } while (0)

int main(void)
{
    /* T2: CPU formula. Totals +400, idle +300 -> 25.0 % */
    cpu_sample_t a = {100, 0, 100, 700, 100, 0, 0, 0};       /* total 1000, idle 800 */
    cpu_sample_t b = {150, 0, 150, 1000, 100, 0, 0, 0};      /* total 1400, idle 1100 */
    CHECK(fabs(cpu_usage_percent(&a, &b) - 25.0) < 0.001, "CPU: delta total 400, delta idle 300 gives 25.0%");
    CHECK(cpu_usage_percent(&a, &a) == 0.0, "CPU: identical samples give 0% (no division by zero)");

    /* Process name containing spaces and a ')' must be parsed from the LAST ')' */
    char name[64]; unsigned long long ut = 0, st = 0;
    const char *line = "1234 (Web (Content) x) S 1 1 1 0 -1 4194304 10 0 0 0 250 50 0 0 20 0 1 0 100 1000 100";
    CHECK(proc_parse_stat(line, name, sizeof name, &ut, &st) == 0 && !strcmp(name, "Web (Content) x") && ut == 250 && st == 50,
          "PROC: parses name with spaces/parentheses and utime/stime");
    CHECK(proc_parse_stat("garbage", name, sizeof name, &ut, &st) != 0, "PROC: malformed line is rejected");

    /* Live readers return sane values */
    mem_info_t m; disk_info_t d; cpu_sample_t s;
    CHECK(mem_read(&m) == 0 && m.percent >= 0 && m.percent <= 100 && m.total_kb > 0, "MEM: live /proc/meminfo read is sane");
    CHECK(disk_read("/", &d) == 0 && d.percent >= 0 && d.percent <= 100, "DISK: live statvfs('/') is sane");
    CHECK(disk_read("/no/such/dir", &d) != 0, "DISK: invalid path is rejected");
    CHECK(cpu_read_sample(&s) == 0, "CPU: live /proc/stat read works");

    /* T9: alert state machine with a simulated sequence (cooldown 30 s) */
    config_t c; config_defaults(&c);
    strcpy(c.logfile, "/tmp/sysalert_test.log"); c.notify = 0; c.cooldown = 30; c.th[R_CPU] = 80;
    alert_init(&c);
    int e1 = alert_check(R_CPU, 50, 0);     /* normal */
    int e2 = alert_check(R_CPU, 85, 2);     /* first breach -> ALERT */
    int e3 = alert_check(R_CPU, 90, 4);     /* inside cooldown -> silent */
    int e4 = alert_check(R_CPU, 90, 40);    /* cooldown passed -> REMINDER */
    int e5 = alert_check(R_CPU, 40, 42);    /* below threshold -> RECOVERED */
    int e6 = alert_check(R_CPU, 40, 44);    /* stays normal -> silent */
    CHECK(e1 == EV_NONE && e2 == EV_ALERT && e3 == EV_NONE && e4 == EV_REMINDER && e5 == EV_RECOVERED && e6 == EV_NONE,
          "ALERT: sequence 50,85,90,90,40 gives ALERT, silence, REMINDER, RECOVERED");
    CHECK(alert_count(EV_ALERT) == 1 && alert_count(EV_REMINDER) == 1 && alert_count(EV_RECOVERED) == 1, "ALERT: exactly one of each event");
    CHECK(alert_check(R_MEM, 80.0, 50) == EV_NONE, "ALERT: value equal to threshold is not a breach");
    alert_close();

    /* T10: validation */
    config_t v; config_defaults(&v); v.th[0] = 150;
    CHECK(config_validate(&v) != 0, "CONFIG: CPU threshold 150 rejected");
    config_defaults(&v); v.th[1] = -5;
    CHECK(config_validate(&v) != 0, "CONFIG: memory threshold -5 rejected");
    config_defaults(&v); v.interval = 0;
    CHECK(config_validate(&v) != 0, "CONFIG: interval 0 rejected");
    config_defaults(&v);
    CHECK(config_validate(&v) == 0, "CONFIG: defaults are valid");
    double dd;
    CHECK(parse_double_strict("abc", &dd) != 0 && parse_double_strict("12.5", &dd) == 0, "CONFIG: 'abc' rejected, '12.5' accepted");

    printf("\n%s (%d failed)\n", failed ? "SOME TESTS FAILED" : "ALL TESTS PASSED", failed);
    return failed ? 1 : 0;
}
