# Test record

These runs were performed by the assistant in a Linux sandbox (Ubuntu 24.04, GCC 13.3), NOT on the team's own computer.
Repeat them on your machine and record your own results and screenshots for the report (Table 7.1).

| ID | Test | Command | Result in sandbox |
|---|---|---|---|
| T1 | Compile with `-Wall -Wextra` | `make` | Compiled, no warnings |
| T2 | CPU formula | `make test` | PASS (400 total / 300 idle = 25.0 %) |
| T3 | Memory (live read sane; formula) | `make test`, `free -m` | PASS; 5.5 % vs free -m 219/3997 MB |
| T4 | Disk vs df | `./bin/sysalert`, `df -h /` | 46.2 % vs df 47 % (df rounds up) |
| T6 | Top processes | busy loop + `/api/status` | busy `sh` shown at 99.8 % CPU |
| T7 | Live breach | `-m 1` | ALERT written to console and log |
| T8 | Cooldown | `make test`, `--test-mode -k 3` | PASS (silent inside cooldown, REMINDER after) |
| T9 | Recovery (simulated) | `--test-mode tests/data/breach_recovery.txt` | ALERT -> REMINDER -> RECOVERED |
| T10 | Invalid thresholds/inputs | `-c 150`, `-m -5`, `-c abc`, `-i 0`, `-n 99`, `--count x` | Rejected, message, exit status 1 |
| T11 | Invalid path | `-p /no/such/dir` | Error, exit status 1 |
| T12 | Ctrl+C | SIGINT during run | "Stopped cleanly", exit status 0, final log line |
| T13 | notify-send absent | default run | One info message, program continues |
| T15 | Log format | `cat logs/alerts.log` | `YYYY-MM-DD HH:MM:SS [LEVEL] text` |
| - | Web API | `curl /api/status`, `/api/config?...` | JSON valid; bad values rejected (400) |
| - | Sanitizers | `-fsanitize=address,undefined` | Unit tests and a 3-sample run: no errors |

Not tested in the sandbox: T14 (unreadable /proc entries as a normal user - the sandbox user can read everything), desktop notifications with a real `notify-send`, and the browser rendering of the dashboard.
