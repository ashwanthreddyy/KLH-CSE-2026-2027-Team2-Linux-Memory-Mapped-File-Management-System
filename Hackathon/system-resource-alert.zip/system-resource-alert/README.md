# System Resource Alert and Notification System (Batch 2)

A C program for Linux that monitors **CPU, memory, disk and processes**, raises **alerts** when thresholds are
exceeded (console + timestamped log + optional desktop notification) and serves a **web dashboard** at
`http://localhost:8080`. Built with only GCC, Make and the standard Linux interfaces (`/proc`, `statvfs()`,
`clock_gettime()`, `sigaction()`). No root access, no third-party packages.

## 1. Run it in VS Code

**Windows:** install WSL 2 with Ubuntu (`wsl --install` in PowerShell), install the VS Code extension
**WSL** (and optionally *C/C++*), then open this folder with *Remote-WSL: Open Folder in WSL*.
**Ubuntu/Linux:** just open the folder in VS Code.

In the VS Code terminal (Ctrl+`):

```bash
sudo apt update && sudo apt install -y build-essential     # GCC and Make (one time)
make                       # compile with -Wall -Wextra  -> bin/sysalert
make test                  # unit tests (deterministic)
./bin/sysalert             # start; then open http://localhost:8080 in your browser
```
Press **Ctrl+C** in the terminal to stop cleanly. Tasks are also available in VS Code via
*Terminal > Run Task* (Build, Run unit tests, Run dashboard, Demo).
Under WSL 2, `http://localhost:8080` opens in your normal Windows browser.

## 2. Options

| Option | Default | Meaning |
|---|---|---|
| `-c, --cpu N` | 80 | CPU threshold % |
| `-m, --mem N` | 80 | Memory threshold % |
| `-d, --disk N` | 90 | Disk threshold % |
| `-p, --path DIR` | `/` | Directory whose file system is monitored |
| `-i, --interval S` | 2 | Refresh interval, seconds (1-3600) |
| `-k, --cooldown S` | 30 | Seconds between repeated alerts |
| `-n, --top N` | 5 | Processes shown (1-20) |
| `-l, --log FILE` | `logs/alerts.log` | Log file |
| `-f, --config FILE` | none | `key=value` config file (see `config.example`) |
| `-P, --port N` | 8080 | Web dashboard port; `0` = console only |
| `--count N` | unlimited | Stop after N samples |
| `--no-notify` | | Disable desktop notifications |
| `--test-mode FILE` | | Use SIMULATED `cpu mem disk` values from FILE |

Thresholds can also be changed live from the dashboard. The web server listens on **127.0.0.1 only**.

## 3. Demonstration script (safe)

```bash
cd system-resource-alert
make                                              # 1. compile
./bin/sysalert                                    # 2. live CPU/memory/disk/processes in the browser
# Ctrl+C
./bin/sysalert -m 1 -i 1 -k 5                     # 3. REAL alert: memory threshold set absurdly low
tail -n 20 logs/alerts.log                        # 4. show the log (second terminal)
# Ctrl+C                                          # 5. clean stop (final log line)
./bin/sysalert --test-mode tests/data/breach_recovery.txt -P 0 -i 1 -k 3 --no-notify
                                                  # 6. SIMULATED ALERT -> REMINDER -> RECOVERED
./bin/sysalert -c 150                             # 7. invalid input is rejected
```
Nothing here fills the disk, exhausts RAM or kills processes. Simulated values are always labelled `[SIMULATED]`.

## 4. How it works (short)

* **CPU %** = 100 x (delta total - delta idle) / delta total, from two samples of the first line of `/proc/stat` (interval-based).
* **Memory %** = (MemTotal - MemAvailable) / MemTotal from `/proc/meminfo` (instantaneous).
* **Disk %** = used / (used + available) from `statvfs()` - the same convention as `df`.
* **Processes**: `/proc/[pid]/stat` (utime+stime ticks, delta / (CLK_TCK x seconds), relative to one core) and `/proc/[pid]/statm` (resident pages). Vanished, unreadable or malformed entries are skipped.
* **Alerts**: per resource NORMAL/ALERTING state. First breach -> ALERT; still above after the cooldown -> REMINDER; back at or below -> RECOVERED.

## 5. Files

```
src/main.c        control loop, signals, test mode
src/config.c      defaults, config file, options, validation
src/monitors.c    CPU, memory, disk and process monitors
src/alert.c       alert engine + logger + optional notify-send notifier
src/server.c      tiny HTTP server (/, /api/status, /api/config)
web/index.html    the dashboard page
tests/            unit tests + simulated data      logs/  log output
```
(In the project report the monitors, logger and notifier are described as separate modules; here they are grouped into
`monitors.c` and `alert.c`. The report's terminal dashboard is replaced by the web dashboard plus a one-line console status per sample.)

## 6. Logs
View: `tail -n 20 logs/alerts.log`, live: `tail -f logs/alerts.log`. Clear (after stopping the program): `: > logs/alerts.log`.
Rotate: `mv logs/alerts.log logs/alerts-$(date +%F).log`.

## 7. Limitations
Polling can miss spikes shorter than the interval; CPU is system-wide; process CPU/memory are approximate (a new process shows 0% for its first sample;
resident memory counts shared pages); under WSL the numbers describe the WSL VM and `notify-send` usually does not work (the program continues
without it); `/proc` entries hidden by the system cannot be read by a normal user; one disk path at a time; threshold changes from the dashboard are not saved to the config file.
